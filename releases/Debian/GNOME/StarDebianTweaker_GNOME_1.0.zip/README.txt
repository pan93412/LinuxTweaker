StarDebianTweaker 如何使用？

一、 結構
Star Debian Tweaker 的資料夾結構
 - StarDebianTweaker.sh （Star Debian Tweaker 主程式，優先執行！）
 - KeyboardSet.sh （中文輸入法的設定程序，建議第二順位執行。）
 - Changelogs.log （版本的更新紀錄）
 - README.txt （說明檔案）
 - Wayland2Xorg-Tool [Folder]
   - Wayland2Xorg.sh （停用 Wayland，改使用 Xorg 當作 Session Type，建議第三順位執行）

二、 使用
1. 開啟 StarDebianTweaker.sh 並照著步驟執行
2. 離開電腦休息一下！
3. 大約 1 ～ 1.5 個小時過後，回到電腦，若程式停住沒有接下去執行，請重開機後再重新啟動這個程式
4. 完成後電腦會重開機，然後開啟 KeyboardSet.sh，按下 Enter 後等待執行完成
5. 再設定 Wayland2Xorg，完成後會自行重啟。
6. Enjoy Your GNOME!

三、 Bug 回報
作者 Telegram： @byStarTW_TW
作者 Twitter： @byStarTW
歡迎回報 Bug。

二、作者
byStarTW
